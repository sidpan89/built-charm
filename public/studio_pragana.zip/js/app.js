
const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));

function setYear(){ const y=document.getElementById('year'); if (y) y.textContent = new Date().getFullYear(); }

function overlayNav(){
  const menuBtn = document.getElementById('menuToggle');
  const closeBtn = document.getElementById('closeNav');
  const overlay = document.getElementById('overlayNav');
  const toggle = (open) => {
    const next = (typeof open === 'boolean') ? open : !overlay.classList.contains('open');
    overlay.classList.toggle('open', next);
    document.body.classList.toggle('nav-open', next);
    menuBtn?.setAttribute('aria-expanded', String(next));
    overlay?.setAttribute('aria-hidden', String(!next));
  };
  menuBtn?.addEventListener('click', () => toggle(true));
  closeBtn?.addEventListener('click', () => toggle(false));
  overlay?.addEventListener('click', (e) => { if (e.target === overlay) toggle(false); });
}

function heroSlideshow(){
  const slides = $$('.slide'); if (!slides.length) return;
  let idx = 0;
  setInterval(() => { slides[idx].classList.remove('active'); idx=(idx+1)%slides.length; slides[idx].classList.add('active'); }, 8200);
}

function ioReveals(container=document){
  const io = new IntersectionObserver((entries)=>{ entries.forEach(e => { if (e.isIntersecting){ e.target.classList.add('in-view'); io.unobserve(e.target); } }); }, { threshold: 0.2 });
  $$('.reveal', container).forEach(el => io.observe(el));
}

function wordsManifest(rootEl){
  const targets = [rootEl.querySelector('.headline'), rootEl.querySelector('.lead')].filter(Boolean);
  targets.forEach(el => {
    if (el.dataset.manifested) return;
    el.dataset.manifested="1";
    const parts = el.textContent.trim().split(/\s+/);
    el.textContent = '';
    parts.forEach((w)=>{
      const span = document.createElement('span');
      span.className='word';
      span.textContent = w;
      el.appendChild(span);
    });
    const words = $$('.word', el);
    /* Speed up the word reveal on the About page.  When the page's
       body has the class `page-about` we reduce both the initial delay
       and the per‑word increment so the text appears faster. */
    const isAbout = document.body.classList.contains('page-about');
    const baseDelay = isAbout ? 90 : 220;
    const stepDelay = isAbout ? 60 : 110;
    words.forEach((w,i)=> setTimeout(()=> w.classList.add('in'), baseDelay + i*stepDelay));
  });
}

function headlineStagger(container=document){
  $$('.headline', container).forEach(h => wordsManifest(h.parentElement || container));
}

function tiltify(){
  const max = 8;
  $$('.tilt').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width;
      const py = (e.clientY - r.top) / r.height;
      const rx = (py - 0.5) * max;
      const ry = (0.5 - px) * max;
      card.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg)`;
    });
    card.addEventListener('mouseleave', () => { card.style.transform = ''; });
  });
}

function filtersProjects(){
  const grid = document.getElementById('projectGrid');
  if (!grid) return;
  const btns = $$('.filter-btn', grid.closest('main') || document);
  btns.forEach(btn => btn.addEventListener('click', () => {
    btns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const f = btn.dataset.filter;
    $$('.project-card', grid).forEach(card => {
      const cat = card.getAttribute('data-cat');
      card.style.display = (f==='all'|| f===cat) ? '' : 'none';
    });
  }));
}

function preloader(){
  const pre = document.getElementById('preloader');
  window.addEventListener('load', () => { if (pre) setTimeout(() => pre.classList.add('hidden'), 250); });
}

function splashIntro(){
  const splash = document.getElementById('splash');
  const text = document.getElementById('splashText');
  if (!splash || !text) return;
  const chars = Array.from("Studio Prangana"); // ensure visible space
  text.textContent = '';
  chars.forEach((c,i)=>{
    const span = document.createElement('span');
    span.className = 'char';
    if (c === ' ') { span.classList.add('space'); span.textContent = '\u00A0'; }
    else { span.textContent = c; }
    text.appendChild(span);
    setTimeout(()=> span.classList.add('in'), 90*i + 200);
  });
  setTimeout(()=> splash.classList.add('hidden'), 2600);
  setTimeout(()=> splash.remove(), 3400);
}

function glassCursor(){
  const fx = document.getElementById('glassFX');
  if (!fx) return;
  let idleTimer;
  const onMove = (e) => {
    document.documentElement.style.setProperty('--mx', e.clientX+'px');
    document.documentElement.style.setProperty('--my', e.clientY+'px');
    document.body.classList.remove('mouse-idle');
    clearTimeout(idleTimer);
    idleTimer = setTimeout(()=>document.body.classList.add('mouse-idle'), 1200);
  };
  window.addEventListener('pointermove', onMove);
}

/*
 * Initialize a simple particle system on a full‑screen canvas. This creates
 * drifting particles and connecting lines that evoke a WebGL/3D feel without
 * relying on external libraries. The canvas is added dynamically if not
 * already present. Colours and opacity are tuned to complement the site’s
 * deep red accent. */
function initParticles(){
  // avoid multiple initialisations
  if (window.__particles_init) return;
  window.__particles_init = true;
  let canvas = document.getElementById('particleCanvas');
  if (!canvas){
    canvas = document.createElement('canvas');
    canvas.id = 'particleCanvas';
    document.body.prepend(canvas);
  }
  const ctx = canvas.getContext('2d');
  let width, height;
  const particles = [];
  const numParticles = 80;
  function resize(){
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();
  // initialise particles with random positions and velocities
  for (let i=0; i<numParticles; i++){
    particles.push({
      x: Math.random()*width,
      y: Math.random()*height,
      vx: (Math.random()-0.5)*0.4,
      vy: (Math.random()-0.5)*0.4,
      size: 1 + Math.random()*2
    });
  }
  function update(){
    ctx.clearRect(0,0,width,height);
    // draw particles
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      // bounce off edges
      if (p.x < 0 || p.x > width) p.vx *= -1;
      if (p.y < 0 || p.y > height) p.vy *= -1;
      ctx.beginPath();
      ctx.fillStyle = 'rgba(193,18,45,0.38)';
      ctx.arc(p.x, p.y, p.size, 0, Math.PI*2);
      ctx.fill();
    });
    // draw lines between close particles
    ctx.lineWidth = 1;
    for (let i=0; i<numParticles; i++){
      for (let j=i+1; j<numParticles; j++){
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        if (dist < 120){
          const alpha = 1 - dist / 120;
          ctx.strokeStyle = `rgba(193,18,45,${alpha*0.25})`;
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }
    requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}

/*
 * Create a liquid‑glass background using a canvas with animated metaballs.
 * This effect mimics the fluid glass animations seen in modern UIs. It
 * renders a set of moving blobs using radial gradients and additive
 * blending. The result is an organic, slowly shifting backdrop that
 * gently diffuses colours. The canvas sits behind all content and
 * ignores pointer events.
 */
function initLiquidBackground(){
  // avoid multiple initialisations
  if (window.__liquid_init) return;
  window.__liquid_init = true;
  // create canvas if not present
  let canvas = document.getElementById('liquidCanvas');
  if (!canvas){
    canvas = document.createElement('canvas');
    canvas.id = 'liquidCanvas';
    document.body.prepend(canvas);
  }
  const ctx = canvas.getContext('2d');
  let width, height;
  const blobs = [];
  const blobCount = 18;
  function resize(){
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resize);
  resize();
  // initialise metaballs with random positions, radii and velocities
  for(let i=0;i<blobCount;i++){
    const radius = 60 + Math.random()*100;
    blobs.push({
      x: Math.random()*width,
      y: Math.random()*height,
      r: radius,
      vx: (Math.random()-0.5)*0.6,
      vy: (Math.random()-0.5)*0.6
    });
  }
  function draw(){
    ctx.clearRect(0,0,width,height);
    ctx.globalCompositeOperation = 'lighter';
    // draw each blob as a radial gradient circle
    blobs.forEach(b=>{
      b.x += b.vx;
      b.y += b.vy;
      // bounce off edges
      if(b.x - b.r < 0 || b.x + b.r > width) b.vx *= -1;
      if(b.y - b.r < 0 || b.y + b.r > height) b.vy *= -1;
      const grd = ctx.createRadialGradient(b.x,b.y, b.r*0.2, b.x,b.y,b.r);
      // colours fade from accent to transparent; using brand accent
      grd.addColorStop(0, 'rgba(193,18,45,0.25)');
      grd.addColorStop(0.7, 'rgba(193,18,45,0.04)');
      grd.addColorStop(1, 'rgba(193,18,45,0)');
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r, 0, Math.PI*2);
      ctx.fill();
    });
    ctx.globalCompositeOperation = 'source-over';
    requestAnimationFrame(draw);
  }
  draw();
}

/*
 * Set up smooth page transitions. An overlay element fades in when
 * internal links are clicked, creating a cross‑fade effect between
 * pages. External links (starting with http) and anchor links (hashes)
 * are ignored. The overlay fades out on page show to reveal content.
 */
function setupTransitions(){
  // create overlay if missing
  let overlay = document.getElementById('transitionOverlay');
  if (!overlay){
    overlay = document.createElement('div');
    overlay.id = 'transitionOverlay';
    document.body.appendChild(overlay);
  }
  // ensure overlay starts hidden on page show (including back/forward)
  window.addEventListener('pageshow', () => { overlay.style.opacity = 0; });
  // intercept clicks on internal links
  $$("a[href]").forEach(a => {
    a.addEventListener('click', (e) => {
      const href = a.getAttribute('href');
      if (!href) return;
      // ignore if link opens in new tab, is external, or anchors within page
      if (a.target === '_blank' || href.startsWith('http') || href.startsWith('#') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
      e.preventDefault();
      overlay.style.opacity = 1;
      // wait for transition before navigation
      setTimeout(() => { window.location.href = href; }, 600);
    });
  });
}

function initPage(container=document){
  setYear();
  overlayNav();
  heroSlideshow();
  ioReveals(container);
  headlineStagger(container);
  tiltify();
  filtersProjects();
  glassCursor();
  initParticles();
  initLiquidBackground();
  setupTransitions();
}

preloader();
document.addEventListener('DOMContentLoaded', () => {
  splashIntro();
  initPage(document);
});
